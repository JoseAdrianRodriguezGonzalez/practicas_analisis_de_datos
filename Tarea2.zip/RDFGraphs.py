import rdflib
from rdflib import Graph, Literal, URIRef, Namespace
from rdflib.namespace import RDF, XSD
import networkx as nx
import matplotlib.pyplot as plt

"""
TASK 2:
Knowledge Graphs with RDFLib.

OBJECTIVE:
1. Build an RDF graph about Mexican universities.
2. Define triples (Subject, Predicate, Object).
3. SPARQL queries (Location and Year of foundation).
4. Serialize in Turtle format (.ttl).
5. Visualize with Matplotlib.
"""

def create_knowledge_graph():
    """
    Build the RDF graph and define triples manually.
    """
    print("Creating Knowledge Graph")
    
    g = Graph()
    EX = Namespace("http://example.org/universidades/")
    g.bind("ex", EX)

    # Entities (Universities)
    unam = EX.UNAM
    ipn = EX.IPN
    tec = EX.Tec_de_Monterrey
    itam = EX.ITAM
    udg = EX.UDG
    uam = EX.UAM

    # Properties (Predicates)
    located_in = EX.ubicada_en
    founded_in = EX.fundada_en
    rdf_type = RDF.type
    class_uni = EX.Universidad

    # Define that they are Universities
    g.add((unam, rdf_type, class_uni))
    g.add((ipn, rdf_type, class_uni))
    g.add((tec, rdf_type, class_uni))
    g.add((itam, rdf_type, class_uni))
    g.add((udg, rdf_type, class_uni))
    g.add((uam, rdf_type, class_uni))

    # Locations
    cdmx = Literal("Ciudad de Mexico")
    gdl = Literal("Guadalajara")
    mty = Literal("Monterrey")

    g.add((unam, located_in, cdmx))
    g.add((ipn, located_in, cdmx))
    g.add((itam, located_in, cdmx))
    g.add((uam, located_in, cdmx))
    g.add((tec, located_in, mty))
    g.add((udg, located_in, gdl))

    # Years of foundation
    g.add((unam, founded_in, Literal(1910, datatype=XSD.integer)))
    g.add((ipn, founded_in, Literal(1936, datatype=XSD.integer)))
    g.add((tec, founded_in, Literal(1943, datatype=XSD.integer)))
    g.add((itam, founded_in, Literal(1946, datatype=XSD.integer)))
    g.add((uam, founded_in, Literal(1974, datatype=XSD.integer)))
    g.add((udg, founded_in, Literal(1792, datatype=XSD.integer)))

    print(f"Graph created with {len(g)} triples.")
    return g, EX

def sparql_queries(g, EX):
    """
    Run the SPARQL queries requested in the task.
    """
    print("\nRunning SPARQL Queries")

    # Query 1: List all universities in CDMX
    query_cdmx = """
    SELECT ?name
    WHERE {
        ?uni ex:ubicada_en "Ciudad de Mexico" .
        ?uni rdf:type ex:Universidad .
        BIND(STRAFTER(STR(?uni), "http://example.org/universidades/") AS ?name)
    }
    """
    print(">>> Universities in Ciudad de Mexico:")
    results = g.query(query_cdmx)
    for row in results:
        print(f" - {row.name}")

    # Query 2: Universities founded before 1950
    query_year = """
    SELECT ?name ?year
    WHERE {
        ?uni ex:fundada_en ?year .
        FILTER (?year < 1950)
        BIND(STRAFTER(STR(?uni), "http://example.org/universidades/") AS ?name)
    }
    """
    print("\n>>> Universities founded before 1950:")
    results = g.query(query_year)
    for row in results:
        print(f" - {row.name} (Founded in {row.year})")

def serialize_and_save(g):
    """
    Save the graph in Turtle (.ttl) format.
    """
    file = "results/universidades_mexico.ttl"
    g.serialize(destination=file, format="turtle")
    print(f"\nGraph serialized and saved in: {file}")

def visualize_graph(g):
    """
    Convert RDF triples to a NetworkX graph for visualization.
    """
    print("\nGenerating Graph Visualization")
    
    nx_graph = nx.DiGraph()

    for s, p, o in g:
        subject = s.split('/')[-1]
        obj = o.split('/')[-1] if isinstance(o, URIRef) else o

        # Simplify predicate names
        if p == RDF.type:
            predicate = "es_una"
        elif str(p).endswith("ubicada_en"):
            predicate = "ubicada_en"
        elif str(p).endswith("fundada_en"):
            predicate = "fundada_en"
        else:
            predicate = p.split('/')[-1]

        nx_graph.add_edge(subject, obj, relation=predicate)

    plt.figure(figsize=(12, 10))
    pos = nx.spring_layout(nx_graph, k=0.5, seed=42)

    nx.draw_networkx_nodes(nx_graph, pos, node_size=2000, node_color="skyblue", alpha=0.9)
    nx.draw_networkx_labels(nx_graph, pos, font_size=10, font_weight="bold")
    nx.draw_networkx_edges(nx_graph, pos, width=1.5, alpha=0.6, edge_color="gray", arrowsize=20)

    edge_labels = nx.get_edge_attributes(nx_graph, 'relation')
    nx.draw_networkx_edge_labels(nx_graph, pos, edge_labels=edge_labels, font_color='red', font_size=8)

    plt.title("Knowledge Graph: Universidades Mexicanas")
    plt.axis('off')
    plt.tight_layout()
    plt.savefig("results/knowledge_graph.png")
    print("Visualization saved as 'knowledge_graph.png'")

if __name__ == "__main__":
    graph, namespace = create_knowledge_graph()
    sparql_queries(graph, namespace)
    serialize_and_save(graph)
    visualize_graph(graph)
