import pandas as pd 
import os 
def process_dataset(src,name):
    dataframe=pd.read_csv(src)
    print(dataframe)
    Labels=dataframe.iloc[:,-1].values
    Features=dataframe.iloc[:,:-1].values
    print(f"Nombre del archivo: {name}")
    print(f"Filas dataframe: {dataframe.shape[0]}")
    print(f"Columnas dataframe: {dataframe.shape[1]}")
    print(f"Tamaño de matriz de características (r,c) {Features.shape}")
    print(f"Tamaño de matriz de etiquetas (r,c) {Labels.shape}")

def main():
    for file in os.listdir("data"):
        process_dataset(os.path.join("data",file),file)
main()