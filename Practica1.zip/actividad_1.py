import sqlite3
import pandas as pd
import os
import seaborn as sns
import matplotlib.pyplot as plt

#Configuración de Ruta
carpeta = r"C:\Users\hemil\OneDrive\Escritorio\Universidad\6to Semestre\Analisis de Datos\Practica 1"
nombre = "Chinook_Sqlite.sqlite"
ruta = os.path.join(carpeta, nombre)

if not os.path.exists(ruta):
    print(f"NO encontrada en: {ruta}")

conexion = sqlite3.connect(ruta)

#----------------------------------------------------------
# CONSULTAS

"""
Ventas totales por país

Escribir una consulta SQL que agregue datos de ventas por país.
Considerar usar 'SUM()' para calcular las ventas totales y 'GROUP BY' para agrupar los resultados por país.

"""
paises = """
    SELECT BillingCountry, SUM(Total) as TotalSales
    FROM Invoice
    GROUP BY BillingCountry
    ORDER BY TotalSales DESC
"""
df_ventas_pais = pd.read_sql_query(paises, conexion)
print("Ventas totales por paises")
print(df_ventas_pais) 
print("\n")

#----------------------------------------------------------
"""
Artistas con más temas en listas de reproducción

Construir una consulta que cuente el número de pistas asociadas a cada artista en las listas de reproducción.
Utilizar sentencias 'JOIN' para conectar tablas relevantes (por ejemplo, artistas, temas, listas de reproducción).
"""
artistas = """
    SELECT ar.Name as ArtistName, COUNT(pt.TrackId) as TrackCount
    FROM Artist ar
    JOIN Album al ON ar.ArtistId = al.ArtistId
    JOIN Track t ON al.AlbumId = t.AlbumId
    JOIN PlaylistTrack pt ON t.TrackId = pt.TrackId
    GROUP BY ar.Name
    ORDER BY TrackCount DESC
    LIMIT 10
"""
df_artistas = pd.read_sql_query(artistas, conexion)
print("Artistas con más reproducciones")
print(df_artistas)
print("\n")

#----------------------------------------------------------
"""
Evolución mensual de ventas

Crear una consulta que extraiga datos de ventas mensualmente.
Utilizar 'strftime()' para formatear fechas y 'GROUP BY' para resumir las ventas por mes.
"""
ventas = """
    SELECT strftime('%Y-%m', InvoiceDate) as Month, SUM(Total) as MonthlySales
    FROM Invoice
    GROUP BY Month
    ORDER BY Month
"""
df_ventas = pd.read_sql_query(ventas, conexion)
print("Evolución mensual de ventas")
print(df_ventas)
print("\n")


#---------------------------------------------------------
# VISUALIZACIÓN DE LA INFORMACIÓN

"""
Mapa de Calor de Ventas por país/año
Utilizar 'heatmap()' para visualizar las ventas totales en diferentes países y años.

"""
query_heatmap = """
    SELECT strftime('%Y', InvoiceDate) as Year, BillingCountry, SUM(Total) as TotalSales
    FROM Invoice
    GROUP BY Year, BillingCountry
"""
df_heatmap_data = pd.read_sql_query(query_heatmap, conexion)
df_pivot = df_heatmap_data.pivot(index='BillingCountry', columns='Year', values='TotalSales')
df_pivot = df_pivot.fillna(0) # Rellenar ceros si no hubo ventas ese año

plt.figure(figsize=(12, 8))
sns.heatmap(df_pivot, annot=True, fmt=".1f", cmap="YlGnBu", linewidths=.5)
plt.title('Mapa de Calor: Ventas Totales por País y Año')
plt.show()

"""
Top 10 artistas por presencia en listas de reproducción

Crear un gráfico de barras para mostrar los 10 artistas principales según el número de pistas en las listas de reproducción.
"""
plt.figure(figsize=(10, 6))
sns.barplot(x='TrackCount', y='ArtistName', data=df_artistas, palette='viridis')
plt.title('Top 10 Artistas en Listas de Reproducción')
plt.xlabel('Número de Pistas')
plt.ylabel('Artista')
plt.show()

"""
Serie Mensual de Ventas

Generar un gráfico de líneas para ilustrar la tendencia de las ventas a lo largo de los meses.
"""
plt.figure(figsize=(12, 6))
sns.lineplot(data=df_ventas, x='Month', y='MonthlySales', marker='o')
plt.title('Tendencia de Ventas Mensuales')
plt.xticks(rotation=45) # Rotar las fechas para que se lean bien
plt.tight_layout()
plt.show()

conexion.close() #Fin