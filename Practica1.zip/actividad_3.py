import requests 
from bs4 import BeautifulSoup 
import spacy
import json 

# Download HTML 
url = "https://es.wikipedia.org/wiki/Python"
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"
}
response = requests.get(url, headers=headers)
html_content = response.text

# Verify response
print("HTTP response code: ", response.status_code) # 200 is OK

# Parse HTML
soup = BeautifulSoup(html_content, 'html.parser')

# Extract tittle
tittle_tag = soup.find("h1")
if(tittle_tag):
    tittle = tittle_tag.get_text()
else:
    tittle = "No tittle found"

# Extract sections h2 and h3
sections = [sec.get_text() for sec in soup.find_all(["h2", "h3"])]

# Extract paragraphs
paragraphs = [par.get_text() for par in soup.find_all("p")]

# Extract tables 'wikitable'
tables = [tab.get_text() for tab in soup.find_all("table", class_="wikitable")]

# Cleaning residuals 
# BeautifulSoup .get_text() already removes tags, but we need to remove extra spaces and newlines
cleaned_paragraphs = [par.strip() for par in paragraphs if par.strip()]

# Load spaCy model
nlp = spacy.load("es_core_news_sm")
doc = nlp(" ".join(cleaned_paragraphs))

# Extract entities
entities = [(ent.text, ent.label_) for ent in doc.ents]

# Paragraph classification by topic
paragraphs_by_topic = {}
for par in cleaned_paragraphs:
    doc_par = nlp(par)
    topics = [ent.label_ for ent in doc_par.ents]
    paragraphs_by_topic[par] = topics

# Export to JSON
data = {
    "tittle": tittle,
    "sections": sections,
    "paragraphs": cleaned_paragraphs,
    "tables": tables,
    "entities": entities,
    "paragraphs_by_topic": paragraphs_by_topic
}

with open("python_wikipedia.json", "w", encoding="utf-8") as json_file:
    json.dump(data, json_file, ensure_ascii=False, indent=4)

print("Data exported to python_wikipedia.json")