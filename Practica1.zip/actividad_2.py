import pandas as pd
import numpy as np
import os
'''
Intrucciones:


En esta actividad, aplicarás modelos estadísticos a datos estructurados que tienen un componente temporal, 
permitiendo obtener una visión más profunda de tendencias y patrones.


Paso 1: Cargar datos

Descarga el conjunto de datos Calidad del Aire UCI desde el enlace proporcionado.
Usar pandas para cargar el conjunto de datos en un DataFrame, asegurando que se analizan correctamente 
las fechas.

Ejemplo: Pitón df = pd.read_csv('path_to_your/air_quality.csv', parse_dates=['date_column'])



Paso 2: Limpieza de datos

La limpieza de datos es crucial para un análisis preciso. Sigue estos pasos:

    Interpolación de valores faltantes

        Utiliza el método estacional para completar cualquier valor que falte en tu conjunto de datos.

        Ejemplo: Pitón df.interpolate(método='tiempo', en situ=True)


    Detección de Valores Atípicos

Implementar el método IQR modificado para identificar y gestionar valores atípicos en tus datos.

Paso 3: Análisis

Realiza los siguientes análisis sobre tu conjunto de datos limpio:

    Descomposición estacional

        Utilizar la función 'seasonal_decompose()' para desglosar la serie temporal en componentes de 
        tendencia, estacionales y residuales.

    Modelaje ARIMA

        Ajusta un modelo ARIMA a tus datos de series temporales.
        Asegurarse de determinar los parámetros apropiados (p, d, q) mediante análisis.
    
    Pronóstico a 30 días con intervalos de confianza

        Generar una previsión para los próximos 30 días e incluir intervalos de confianza en tus resultados.

Paso 4: Evaluación

    Calcular el Error Cuadrático Medio Raíz (RMSE) en tu conjunto de pruebas para evaluar el rendimiento 
    de tu modelo.
    Ejemplo: Pitón de sklearn.metrics importa mean_squared_error rmse = mean_squared_error(test_set, predicciones, al cuadrado=Falso)
'''

import matplotlib.pyplot as plt
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_squared_error
import warnings
warnings.filterwarnings('ignore')

# PASO 1: CARGAR DATOS 
# Cargar el dataset con separador de punto y coma y coma como decimal
datos_brutos = pd.read_csv('AirQualityUCI.csv', sep=';', decimal=',')

# Mostrar información básica
print("Forma del dataset:", datos_brutos.shape)
print("\nPrimeras filas:")
print(datos_brutos.head())
print("\nColumnas:", datos_brutos.columns.tolist())
print("\nValores faltantes por columna:")
print(datos_brutos.isnull().sum())

# PASO 2: LIMPIEZA DE DATOS 
# Crear copia para no modificar original
datos_limpios = datos_brutos.copy()

# Reemplazar valores -200 que representan datos faltantes con NaN
datos_limpios = datos_limpios.replace(-200.0, np.nan)

# Seleccionar columnas numéricas para análisis (excluyendo Date, Time y columnas vacías)
columnas_numericas = datos_limpios.select_dtypes(include=[np.number]).columns.tolist()

print("\nColumnas numéricas a analizar:", columnas_numericas)

# Interpolación lineal para valores faltantes
for columna in columnas_numericas:
    datos_limpios[columna].interpolate(method='linear', inplace=True)

# Rellenar valores restantes con forward fill
datos_limpios[columnas_numericas] = datos_limpios[columnas_numericas].ffill().bfill()

print("\nValores faltantes después de interpolación:")
print(datos_limpios[columnas_numericas].isnull().sum())

# Detección de outliers usando método IQR
def detectar_outliers_iqr(datos, columna, factor=1.5):
    """Detecta outliers en una columna usando el método IQR"""
    q1 = datos[columna].quantile(0.25)
    q3 = datos[columna].quantile(0.75)
    iqr = q3 - q1
    limite_inferior = q1 - factor * iqr
    limite_superior = q3 + factor * iqr
    return (datos[columna] < limite_inferior) | (datos[columna] > limite_superior)

# Aplicar detección y mostrar cantidad de outliers
print("\n Detección de Outliers (IQR) ")
for columna in columnas_numericas[:3]:  # Mostrar para primeras 3 columnas
    outliers_detectados = detectar_outliers_iqr(datos_limpios, columna)
    cantidad_outliers = outliers_detectados.sum()
    print(f"{columna}: {cantidad_outliers} outliers detectados")

# PASO 3: ANÁLISIS
print("\nANÁLISIS DE SERIES TEMPORALES")

# Usar la columna con menos valores faltantes para análisis (PT08.S1(CO))
columna_analisis = 'PT08.S1(CO)'
serie_temporal = datos_limpios[columna_analisis].dropna()
serie_temporal = serie_temporal[:3000]  # Usar subset para ARIMA eficiente

print(f"\nAnalizando columna: {columna_analisis}")
print(f"Longitud de la serie: {len(serie_temporal)}")

# Descomposición estacional (período de 168 para datos horarios = 1 semana)
try:
    descomposicion = seasonal_decompose(serie_temporal, model='additive', period=168)
    
    # Graficar descomposición
    fig, ejes = plt.subplots(4, 1, figsize=(12, 10))
    descomposicion.observed.plot(ax=ejes[0], color='blue')
    ejes[0].set_ylabel('Observado')
    ejes[0].set_title(f'Descomposición Estacional - {columna_analisis}')
    
    descomposicion.trend.plot(ax=ejes[1], color='green')
    ejes[1].set_ylabel('Tendencia')
    
    descomposicion.seasonal.plot(ax=ejes[2], color='orange')
    ejes[2].set_ylabel('Estacional')
    
    descomposicion.resid.plot(ax=ejes[3], color='red')
    ejes[3].set_ylabel('Residual')
    ejes[3].set_xlabel('Índice')
    
    plt.tight_layout()
    plt.savefig('descomposicion_estacional.png', dpi=100)
    print("Gráfico de descomposición guardado: descomposicion_estacional.png")
    plt.close()
except Exception as e:
    print(f"Error en descomposición: {e}")

# División en conjuntos entrenamiento y prueba
tamanio_entrenamiento = int(len(serie_temporal) * 0.8)
datos_entrenamiento = serie_temporal[:tamanio_entrenamiento]
datos_prueba = serie_temporal[tamanio_entrenamiento:]

print(f"\nTamaño entrenamiento: {len(datos_entrenamiento)}")
print(f"Tamaño prueba: {len(datos_prueba)}")

# Modelaje ARIMA con parámetros determinados
try:
    print("\nAjustando modelo ARIMA(1,1,1)")
    modelo_arima = ARIMA(datos_entrenamiento, order=(1, 1, 1))
    resultado_arima = modelo_arima.fit()
    print(resultado_arima.summary())
    
    # Predicciones en conjunto de prueba
    predicciones_prueba = resultado_arima.forecast(steps=len(datos_prueba))
    
    # RMSE
    rmse = np.sqrt(mean_squared_error(datos_prueba, predicciones_prueba))
    print(f"\nRMSE en conjunto de prueba: {rmse:.4f}")
    
    # Gráfico de predicciones vs real
    plt.figure(figsize=(12, 6))
    plt.plot(datos_prueba.index, datos_prueba.values, label='Datos reales', color='blue', marker='o')
    plt.plot(datos_prueba.index, predicciones_prueba.values, label='Predicciones ARIMA', color='red', linestyle='--')
    plt.xlabel('Índice')
    plt.ylabel('Valor')
    plt.title(f'Predicciones ARIMA vs Datos Reales - {columna_analisis}')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('predicciones_arima.png', dpi=100)
    print("Gráfico de predicciones guardado: predicciones_arima.png")
    plt.close()
    
except Exception as e:
    print(f"Error en ARIMA: {e}")

# PASO 4: PRONÓSTICO A 30 DÍAS
    print("\n PRONÓSTICO A 30 DÍAS ")
    # Reajustar con todos los datos disponibles
    modelo_final = ARIMA(serie_temporal, order=(1, 1, 1))
    resultado_final = modelo_final.fit()
    
    # Pronóstico a 30 días con intervalos de confianza
    pronostico_30_dias = resultado_final.get_forecast(steps=30)
    tabla_pronostico = pronostico_30_dias.summary_frame()
    
    print("\nPronóstico para los próximos 30 períodos:")
    print(tabla_pronostico)
    
    # Guardar pronóstico en CSV
    tabla_pronostico.to_csv('pronostico_30_periodos.csv')
    print("Pronóstico guardado: pronostico_30_periodos.csv")
    
    # Gráfico de pronóstico
    plt.figure(figsize=(12, 6))
    plt.plot(serie_temporal.index[-100:], serie_temporal.values[-100:], label='Datos históricos', color='blue')
    plt.plot(range(len(serie_temporal), len(serie_temporal)+30), tabla_pronostico['mean'], 
             label='Pronóstico', color='red', linestyle='--', marker='o')
    plt.fill_between(range(len(serie_temporal), len(serie_temporal)+30),
                     tabla_pronostico['mean_ci_lower'],
                     tabla_pronostico['mean_ci_upper'],
                     alpha=0.2, color='red', label='Intervalo de confianza 95%')
    plt.xlabel('Período')
    plt.ylabel('Valor')
    plt.title(f'Pronóstico a 30 Períodos con Intervalos de Confianza - {columna_analisis}')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('pronostico_30_dias.png', dpi=100)
    print("Gráfico de pronóstico guardado: pronostico_30_dias.png")
    plt.close()
    
except Exception as e:
    print(f"Error en pronóstico: {e}")


